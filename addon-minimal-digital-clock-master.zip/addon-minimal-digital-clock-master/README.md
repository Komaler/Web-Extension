# addon-minimal-digital-clock
A firefox extension that adds minimal digital clock in toolbar.

see https://addons.mozilla.org/en/firefox/addon/minimal-digital-clock/
